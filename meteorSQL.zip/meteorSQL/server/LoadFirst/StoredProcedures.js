//Call Sotred Procedure on the database
var log = new LoggerServer('StroredProcedure.js', CLL.error);

/*  supportered data types for the Sql.driver
 Bit, BigInt, Decimal ([precision], [scale]), Float, Int, Money, Numeric ([precision], [scale]), SmallInt, SmallMoney, Real, TinyInt
 Char ([length]), NChar ([length]), Text, NText, VarChar ([length]), NVarChar ([length]), Xml
 Time ([scale]), Date, DateTime ,DateTime2 ([scale]), DateTimeOffset ([scale]), SmallDateTime
 UniqueIdentifier
 Binary, VarBinary ([length]), Image
 UDT, Geography, Geometry
 */

/* 
 examples of calls
 
 with Input parameters
 var inputs = [{name: "userName", type: Sql.driver.NVarChar, value: email}];
 Meteor.call('callStoredProcedure', '[uspGetRole]', inputs, {}, function (error, result) {
 });
 
 without Input parameters
 Meteor.call('callStoredProcedure', '[uspGetRole]', {}, {}, function (error, result) {
 });
 */

//This will add in the current users e-mail address to the SP as a parameter, it's used for verification that the user
//has permission to run the SP.
Meteor.methods({
    AddEmailToSP: function (SPname, inputObject, outputObject, IDParameter) {
        log.trace("AddEmailToSP");

        log.debug("SPname:" + SPname);
        log.debug("inputObject:" + JSON.stringify(inputObject));
        log.debug("outputObject:" + JSON.stringify(outputObject));
        log.debug("IDParameter:" + JSON.stringify(IDParameter));

        if (typeof inputObject === 'undefined'){
            inputObject = [];
        }
        if (typeof outputObject === 'undefined'){
            outputObject = [];
        }

        log.trace('After inputs tests');

        if (!Lib.JS.isUndefined(IDParameter)) {
            log.trace('IDParameter is not undefined');
            log.trace('Meteor.user().services.google.email:' + Meteor.user().services.google.email);
            var email = Meteor.user().services.google.email;
            log.trace('email:' + email);

            if (!Lib.JS.isUndefined(email)) {
                log.trace('email is not undefined');
                inputObject.push({name: IDParameter, type: SQLTypes.NVarChar, value: email});
            } else {
                log.error('For ' + SPname + ' the meteor email is not correct.  email:' + email);
            }
        } else {
            log.error('For ' + SPname + ' the IDParameter is not correct.  IDParameter:' + IDParameter);
        }

        log.trace('Rigth Before SP');
        return SP(SPname, inputObject, outputObject);
    }
});

//Run an SP on the DB and return the data
function SP(SPname, inputObject, outputObject) {
    log.trace("SP");
    var errorOccured = false;
    if (Lib.JS.isSTREmpty(SPname)) {
        log.error("SPname is empty");
        log.error("SPname:" + SPname);
        return "";
    }

    //log.debug("SPname:" + SPname);

    if (typeof inputObject === 'undefined') {
        log.debug("inputObject is undefined");
    }

    if (typeof outputObject === 'undefined') {
        log.debug("outputObject is undefined");
    }

    var inputCounter = 0;
    for (inputCounter = 0; inputCounter < inputObject.length; inputCounter++) {
        log.trace("inputObject[inputCounter].name:" + inputObject[inputCounter].name);
        log.trace("inputObject[inputCounter].type:" + inputObject[inputCounter].type);
        log.trace("inputObject[inputCounter].value:" + inputObject[inputCounter].value);

        if (inputObject[inputCounter].type === SQLTypes.Int) {
            if(Lib.DB.isString(inputObject[inputCounter].value)){
                inputObject[inputCounter].value = parseInt(inputObject[inputCounter].value)
            }
            
            log.trace("check isInt");
            if (!Lib.DB.isInt(inputObject[inputCounter].value)) {
                typeError(inputObject[inputCounter]);
                errorOccured = true;
                log.trace("check isInt failed");
            } else {
                log.trace("check isInt failed");
            }
            inputObject[inputCounter].type = Sql.driver.Int;
        } else if (inputObject[inputCounter].type === SQLTypes.NVarChar) {
            log.warn('Test not setup for NVarChar so be careful');
            inputObject[inputCounter].type = Sql.driver.NVarChar;
        } else if (inputObject[inputCounter].type === SQLTypes.Bit) {
            log.warn('Test not setup for Bit so be careful');
            inputObject[inputCounter].type = Sql.driver.Bit;
        } else if (inputObject[inputCounter].type === SQLTypes.Date) {
            if (!Lib.DB.isDate(inputObject[inputCounter].value)) {
                typeError(inputObject[inputCounter]);
                errorOccured = true;
            }
            inputObject[inputCounter].type = Sql.driver.Date;
        } else if (inputObject[inputCounter].type === SQLTypes.VarBinary) {
            log.warn('Test not setup for VarBinary so be careful');
            inputObject[inputCounter].type = Sql.driver.VarBinary;
        } else if (inputObject[inputCounter].type === SQLTypes.Decimal) {
            if(Lib.DB.isString(inputObject[inputCounter].value)){
                inputObject[inputCounter].value = parseFloat(inputObject[inputCounter].value)
            }
            
            if (!Lib.JS.isDecimal(inputObject[inputCounter].value)) {
                typeError(inputObject[inputCounter]);
                errorOccured = true;
            }
            inputObject[inputCounter].type = Sql.driver.Decimal;
        } else if (inputObject[inputCounter].type === SQLTypes.Money) {
            log.error("Checking money");
            if(Lib.DB.isString(inputObject[inputCounter].value)){
                inputObject[inputCounter].value = parseFloat(inputObject[inputCounter].value);
            }
            /*if (!Lib.DB.isMoney(inputObject[inputCounter].value)) {
                typeError(inputObject[inputCounter]);
                errorOccured = true;
            }*/
            inputObject[inputCounter].type = Sql.driver.Money;
        } else if (inputObject[inputCounter].type === SQLTypes.DateTime) {
            log.warn('Test not setup for DateTime, use date if possible');
            inputObject[inputCounter].type = Sql.driver.DateTime;
        }
    }

    if (errorOccured) {
        log.error('SP:'+ SPname + ' failed check errors');
        return false;
    }

    var outputCounter = 0;
    for (outputCounter = 0; outputCounter < outputObject.length; outputCounter++) {

        if (outputObject[outputCounter].type === SQLTypes.Int) {
            outputObject[outputCounter].type = Sql.driver.Int;
        } else if (outputObject[outputCounter].type === SQLTypes.NVarChar) {
            outputObject[outputCounter].type = Sql.driver.NVarChar;
        } else if (outputObject[outputCounter].type === SQLTypes.Bit) {
            outputObject[outputCounter].type = Sql.driver.Bit;
        } else if (outputObject[outputCounter].type === SQLTypes.Date) {
            outputObject[outputCounter].type = Sql.driver.Date;
        } else if (outputObject[outputCounter].type === SQLTypes.VarBinary) {
            outputObject[outputCounter].type = Sql.driver.VarBinary;
        } else if (outputObject[outputCounter].type === SQLTypes.Decimal) {
            outputObject[outputCounter].type = Sql.driver.Decimal;
        } else if (outputObject[inputCounter].type === SQLTypes.DateTime) {
            outputObject[inputCounter].type = Sql.driver.DateTime;
        }
    }

    var SPOptions = {
        sp: "[dbo]." + SPname,
        inputs: inputObject,
        outputs: outputObject
    };
    log.trace("calling SQL:" + SPname);

    //var result = Sql.sp(SPOptions)[0];
    
    try {
      var result = Sql.sp(SPOptions)[0];
    } catch (e) {
        log.error(SPname + "ERROR:" + e);
        throw new Meteor.Error(500, 'Error 500: DB Error', e);
        return result;
    }

    
    log.trace("finished calling SQL");
    log.trace("outputObject:" + JSON.stringify(outputObject));
    log.trace("result:" + JSON.stringify(result));
    return result;
}

function typeError(object) {
    log.error(object.name + ' type does not match value');
    log.error('object.type:' + object.type);
    log.error('object.value:' + object.value);
    log.error('object.value typeof:' + (typeof object.value).toString());
}

//basic warpper for the SP function, it validates some of the data and is used for testing.
Meteor.methods({
    callStoredProcedure: function (SPname, inputObject, outputObject) {
        log.trace("callStoredProcedure");
        if (!Lib.DB.validateSQLInputs(inputObject, log)) {
            log.error("SPname:" + SPname + " has failed input validation and was not called");
            return "";
        }

        log.debug("SPname:" + SPname);
        log.debug("inputObject:" + inputObject);
        log.debug("outputObject:" + outputObject);

        if (typeof inputObject === 'undefined'){
            inputObject = [];
        }
        if (typeof outputObject === 'undefined'){
            outputObject = [];
        }

        log.trace("callStoredProcedure validation passed");

        return SP(SPname, inputObject, outputObject);
    }
});


//This code is user called to determin is user can change the information of an order
//See the documentation for specifics.
var securityLog = new LoggerServer('securty.js', CLL.error);

Meteor.methods({
    hasWritePermissionToOrder: function (readOnly, orderInfo) {
        securityLog.trace("hasWritePermissionToOrder");
        securityLog.trace("readOnly:" + readOnly);
        securityLog.trace("orderInfo:" + JSON.stringify(orderInfo));

        //if readOnly = true then true (probably becasue of history page)
        if (readOnly) {
            securityLog.trace("readOnly is true so false");
            return false;
        }

        //if the order has been completed or delted then true
        if (orderInfo.status === OrderStatus.Completed || orderInfo.status === OrderStatus.Deleted) {
            securityLog.trace("status is completed or delted so false");
            return false;
        }

        var email = Meteor.user().services.google.email;

        var results = SP('[uspGetRole]', [{name: 'email', type: SQLTypes.NVarChar, value: email}], []);
        securityLog.trace("[uspGetRole] results:" + JSON.stringify(results));

        var role = results[0].role;
        securityLog.trace("role:" + role);

        //if the user is in the school staff role then false
        if (role === 'SchoolStaff') {
            securityLog.trace("role is school staff so false");
            return false;
        }

        //If the user is an admin or SEACoordinator then true
        if (role === 'Admin' || role === 'SEACoordinator') {
            securityLog.trace("role is Admin OR SEACoordinator so true");
            return true;
        }

        securityLog.trace("orderInfo.equipmentType:" + orderInfo.equipmentType);
        securityLog.trace("orderInfo.tableType:" + orderInfo.tableType);

        //If the user is SEATech and the order is technical then true
        if (role === 'SEATech' && (orderInfo.equipmentType === 'assistive' || orderInfo.tableType === 'techOrder')) {
            securityLog.trace("role is SEATech and assistive order so true");
            return true;
        }

        if (Lib.JS.isUndefined(orderInfo.requester)) {
            securityLog.trace("orderInfo.requester is Undefined so must be a new request, cannot tell what kind of request");
            if (role === 'SEAAdminAsst' || role === 'SEAAdminAsstU8' || role === 'SEATech' || role === 'SpecEdConsultant') {
                securityLog.trace("role === SEAAdminAsst || SEAAdminAsstU8 || SEATech || SpecEdConsultant -> true, new order + these creds equals true");
                return true;
            }
        }

        //If the user is SEAAdminAsst and the order is non-technical then true
        if (role === 'SEAAdminAsst' && (orderInfo.equipmentType === 'physical' || orderInfo.tableType === 'order')) {
            securityLog.trace("role is SEAAdminAsst and order is physical so true");
            return true;
        }

        //if the user is SEAAdminAsstU8 and the order ir under $800 and non-technical then true
        if (role === 'SEAAdminAsstU8' && (orderInfo.equipmentType === 'physical' || orderInfo.tableType === 'order') && orderInfo.cost <= 800) {
            securityLog.trace("role is SEAAdminAsstU8 and order is physical and under $800 so true");
            return true;
        }

        securityLog.trace("orderInfo.requester:" + orderInfo.requester);

        //If the user is the requestor then true
        if (orderInfo.requester === 'serverEamil') {
            securityLog.trace("user is the requester so true");
            return true;
        }

        //If the user is a SpecEdConsultant and belongs to this school then true
        if (role === 'SpecEdConsultant') {
            securityLog.trace("[uspIsSchoolConsultant] email:" + JSON.stringify(email));
            securityLog.trace("[uspIsSchoolConsultant] orderInfo.ID:" + JSON.stringify(orderInfo.ID));
            var results = SP('[uspIsSchoolConsultant]', [{name: 'requesterEmail', type: SQLTypes.NVarChar, value: email}, {name: 'orderID', type: SQLTypes.Int, value: orderInfo.ID}], {});
            securityLog.trace("[uspIsSchoolConsultant] results:" + JSON.stringify(results));
            if (results[0].result === 1) {
                securityLog.trace("role is SpecEdConsultant and they are in charge of the school so true");
                return true;
            } else if (!orderInfo.isLoad) {
                securityLog.trace("role is SpecEdConsultant and they are creating a new order for a student that is not theirs so true");
                return true;
            }
        }

        securityLog.trace("role === 'SpecEdConsultant' : " + (role === 'SpecEdConsultant').toString());

        //otherwise true
        securityLog.trace("else so false");
        return false;
    }
});