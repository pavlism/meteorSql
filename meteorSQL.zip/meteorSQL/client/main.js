import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';

import './main.html';

var SQLResults = new ReactiveArray();

Template.hello.events({
  'click button'(event, instance) {
	  
	var inputs = [{name: "varNAme",type: SQLTypes.NVarChar,value: 'value'}];
	  
    // increment the counter when button is clicked
    Meteor.call('callStoredProcedure', '[uspReportWeekTraining]', {}, {}, function (error, result) {
		Lib.DB.mapSQLArrays(result, SQLResults);
    });
  },
});

Template.hello.helpers({
    SQLResults: function () {
        return SQLResults.toArray();
    }
});